/**
 * Gets the repositories of the user from Github
 */

import { call, put, takeLatest } from 'redux-saga/effects';
import { repoLoadingError } from 'containers/App/actions';

import request from 'utils/request';
import { REQUEST_BALANCE } from './constants';
import { saveBalance } from './actions';
/**
 * Github repos request/response handler
 */
export function* getBalance() {
  // Select username from store
  const requestURL = `/api/ownerTokenBalance`;

  try {
    // Call our request helper (see 'utils/request')
    const repos = yield call(request, requestURL, {
      method: 'POST',
      headers: {
        'x-api-key': '&6831IlYmK33d',
      },
      body: JSON.stringify({
        block: 1,
      }),
    });
    yield put(saveBalance(repos.balance));
  } catch (err) {
    yield put(repoLoadingError(err));
  }
}

/**
 * Root saga manages watcher lifecycle
 */
export default function* githubData() {
  // Watches for LOAD_REPOS actions and calls getRepos when one comes in.
  // By using `takeLatest` only the result of the latest API call is applied.
  // It returns task descriptor (just like fork) so we can continue execution
  // It will be cancelled automatically on component unmount
  yield takeLatest(REQUEST_BALANCE, getBalance);
}
