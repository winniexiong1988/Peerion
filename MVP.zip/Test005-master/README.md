## Quick start

1.  Make sure that you have Node.js v8.10 and npm v5 or above installed.
2.  Run `npm run setup` in order to install dependencies and clean the git repo.<br />
    _At this point you can run `npm start` to see the example app at `http://localhost:3000`._
# Hyeprionx-wallet
# Test004
